# HW 0 
## AVL tree
this project serves to help refamilarize me with c/c++ 

to do this i am writing an AVL tree

## Instructions

to run the program:

`make run`

there are 5 menu options, to select one, type the number after the prompt

**1: Create Tree**

parses a text file of numbers separated by newline characters. 

**2: Insert Node**

inserts a single value into the tree

**3: Search Tree**

Searches if the entered value exists in the tree

**4: traversal**

opens a sub menu to select between pre-order, in-order, and post-order traversals

**5: Exit**

Closes the program